main <- function(filename, alpha, beta, classif_flag)
{
  library(igraph)
  library(dplyr)
  source("generate_Classification_Graph.R")
  source("generate_Clustering_Graph.R")

  df <- 0

  filename1 <- paste0("data/", filename)
  mydata <- read.table(filename1, header=TRUE, sep=",")
  mydata <- na.omit(mydata)
  
  if (classif_flag == 0){
    print(paste("This analysis is done on data set : ", filename, " with value of alpha  = ", alpha, " and value of beta = ", beta, " for classification"))
    df <- generate_Classification_Graph(filename, mydata, alpha, beta)
  }
  
  if (classif_flag == 1){
    print(paste("This analysis is done on data set : ", filename, " with value of alpha  = ", alpha, " and value of beta = ", beta, " for clustering"))
    class <- mydata[ , ncol(mydata)]
    maxclus <- length(unique(class))
    df <- generate_Clustering_Graph(filename, mydata[-ncol(mydata)], maxclus, alpha, beta)
  }
  
  return(df)
  
}